---
title: "La peste del estaño"
icon: "🧊"
curso: "Química 2º Bach"
bloque: "Termoquímica (+1 más)"
tipo: "Transversal (+2 más)"
---

Adaptado de [Scott, Napoleón y la peste del estaño.](http://starcnc.blogspot.com/2016/12/los-miembros-del-equipo-de-scott-en-el.html)

🧊 ¿Puede el frío romper un metal? ¿Y dejar al ejército de Napoleón con las chaquetas abiertas en plena campaña rusa?

Os traigo una miniactividad para 1º de Bachillerato que mezcla ciencia, historia y un poco de mito. Hablamos de la peste del estaño, un fenómeno real que hace que este metal se transforme y se desmorone a bajas temperaturas, generando leyendas de botones caídos y órganos de iglesia desintegrados en invierno.

Tras leer un texto breve pero muy curioso, el alumnado deberá aplicar lo aprendido sobre entalpía, entropía y espontaneidad para calcular la temperatura a la que se produce este extraño cambio físico en el estaño.

🧠 Una forma original y sorprendente de conectar la Termodinámica con un caso histórico que no deja indiferente.

👥 Se puede hacer en parejas o individualmente.

⏱️ Ocupa una sesión de clase o puede utilizarse como ejercicio de cierre o ampliación.

<!-- DOCUMENTO: archivo incrustado (visor embebido) que no terminó de cargar durante la migración automatizada; revisar directamente en la página original -->
