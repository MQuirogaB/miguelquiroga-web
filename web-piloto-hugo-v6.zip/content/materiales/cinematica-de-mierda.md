---
title: "Cinemática de mierda"
icon: "💩"
curso: "1º Bach"
bloque: "Cinemática"
tipo: "Ejercicio (+1 más)"
---

💩 ¿Te puede arruinar un pájaro la cita romántica? ¿Y qué pasa cuando un pingüino decide apuntar con precisión balística?

Os presento esta actividad de cinemática 100% contextualizada (y algo escatológica) que repasa conceptos como el tiempo de vuelo, alcance, descomposición de velocidades y trayectoria parabólica, todo ello envuelto en dos situaciones tan improbables como inolvidables:

- Un inocente picnic bajo un cielo traicionero: calcula a qué distancia cae el "recado" que te lanza un pájaro con muy mala leche.
- Un estudio real (sí, real) sobre las heces proyectadas de los pingüinos emperador: velocidad, ángulo, alcance... ¡y mamparas protectoras!

🧠 Ideal para practicar la cinemática con una sonrisa y hacer que los ejercicios cobren vida.

👥 Se puede hacer en parejas o de forma individual.

⏱️ Se resuelve en una o dos sesiones, dependiendo del nivel del grupo y las risas.

<!-- DOCUMENTO: archivo incrustado (visor embebido) que no terminó de cargar durante la migración automatizada; revisar directamente en la página original -->
