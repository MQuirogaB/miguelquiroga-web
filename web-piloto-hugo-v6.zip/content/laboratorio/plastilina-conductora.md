---
title: "Plastilina conductora"
bloque: "Electromagnetismo"
tipo: "Maker (+1 más)"
---

## Introducción

Los circuitos eléctricos están presentes en todo lo que nos rodea. En esta actividad se creará un circuito eléctrico básico utilizando plastilina conductora casera.

## Objetivos

- Crear plastilina conductora casera.
- Elaborar un circuito eléctrico.

## Materiales

**Para la plastilina**

- Harina
- Sal
- Zumo de limón concentrado
- Colorante alimentario (opcional)

**Para el circuito**

- Leds
- Portapilas
- Pilas
- Zumbadores

## Fundamento científico

Tanto el limón como el agua son conductores de la electricidad. Al hacer una masilla con esto y harina se consigue que esta también la conduzca.

## Procedimiento

1. Haz un montón de harina y añade un poco de sal.
2. Ve añadiendo zumo de limón y remueve.
3. Si ves que se apelmaza en las manos, añade harina.
4. Si no se hace bien la masa, añade zumo de limón.
5. Remueve poco a poco hasta obtener una masa homogénea.
6. Opcionalmente, añade colorante alimentario.

Se propone hacer los siguientes dibujos añadiendo plastilina sobre el papel.
